import React from 'react'
import './DescriptionBox.css'

const DescriptionBox = () => {
  return (
    <div className='descriptionbox'>
        <div className="descriptionbox-navigator">
            <div className="descriptionbox-nav-box">Description</div>
            <div className="descriptionbox-nav-box fade">Reviews (122)</div>
        </div>
        <div className="descriptionbox-description">
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Omnis iste cum molestias necessitatibus accusamus consectetur id facilis tempore magni minus reiciendis exercitationem odit dolore cupiditate nemo, eius voluptatibus provident possimus?</p>
            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Qui corporis soluta nostrum, ad animi minima nesciunt necessitatibus laboriosam blanditiis impedit incidunt recusandae, repellat dignissimos doloremque? Laboriosam deserunt sunt sint veritatis!</p>
        </div>
    </div>
  )
}

export default DescriptionBox